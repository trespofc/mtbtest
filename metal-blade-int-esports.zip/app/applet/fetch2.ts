import https from 'https';

https.get('https://metal-blade-int-professional-free-fire-esports-44266003352.asia-southeast1.run.app/assets/index-lVdIEn8O.js', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    // Regex to find className:"some string" or className:'some string'
    const classNamesRegex = /className:\s*(["'])(.*?)\1/g;
    let match;
    const classNames = [];
    while ((match = classNamesRegex.exec(data)) !== null) {
      if (match[2].length > 5) classNames.push(match[2]);
    }

    const textRegex = /children:\s*(["'])(.*?)\1/g;
    const texts = [];
    while ((match = textRegex.exec(data)) !== null) {
      if (match[2].length > 2) texts.push(match[2]);
    }
    
    // Alse get text inside arrays of children: children: ["Text", ...]
    const arrayRegex = /\[(['"].*?['"])\]/g;
    
    console.log("=== CLASSES ===");
    console.log(classNames.join('\n'));
    console.log("=== TEXT ===");
    console.log(texts.join('\n'));
  });
}).on('error', (err) => {
  console.log('Error: ', err.message);
});
