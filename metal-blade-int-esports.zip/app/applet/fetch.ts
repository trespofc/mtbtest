import https from 'https';

https.get('https://metal-blade-int-professional-free-fire-esports-44266003352.asia-southeast1.run.app/assets/index-lVdIEn8O.js', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    const classNames = data.match(/className:[^"']*["']([^"']+)["']/g) || [];
    const strings = data.match(/children:[^"']*["']([^"']+)["']/g) || [];
    console.log("=== CLASSES ===");
    console.log(classNames.map(c => c.split(/['"]/)[1]).slice(0, 100).join('\n'));
    console.log("=== TEXT ===");
    console.log(strings.map(c => c.split(/['"]/)[1]).slice(0, 100).join('\n'));
    
    // Check raw strings
    const raw = data.match(/"([^"]{15,100})"/g) || [];
    console.log("=== RAW STRINGS ===");
    console.log(raw.slice(0, 100).join('\n'));
  });
}).on('error', (err) => {
  console.log('Error: ', err.message);
});
