import React, { useState } from 'react';
import { Mail, Lock, LogIn, Cpu, AlertCircle, RefreshCcw } from 'lucide-react';
import { motion } from 'motion/react';

interface AdminLoginProps {
  onLogin: (token: string) => void;
}

export default function AdminLogin({ onLogin }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const resp = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await resp.json();
      if (data.success) {
        onLogin(data.token);
      } else {
        setError(data.message || 'Verification Failed. Credentials Invalid.');
      }
    } catch (e) {
      setError('Communication break in terminal link. Re-try log-in sequence.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050510] flex items-center justify-center p-6 font-sans relative overflow-hidden">
      {/* Background Blobs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/10 blur-[120px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-600/10 blur-[120px] rounded-full pointer-events-none"></div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center p-4 bg-purple-600/10 rounded-2xl border border-purple-500/20 mb-6 group hover:border-purple-500/50 transition-all">
            <Cpu className="text-purple-500 w-10 h-10 group-hover:rotate-12 transition-transform" />
          </div>
          <h1 className="text-4xl font-black italic text-white uppercase tracking-tighter mb-2">Command <span className="text-purple-500">Center</span></h1>
          <p className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.4em]">Administrative Access Gateway</p>
        </div>

        <div className="bg-[#0a0a1a] p-10 rounded-[3rem] border border-zinc-800 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] ml-2">Operator ID (Email)</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
                <input 
                  type="email" 
                  autoFocus
                  required
                  autoComplete="email"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl pl-12 pr-6 py-4 text-sm font-bold text-white focus:outline-none focus:border-purple-500 transition-all placeholder:text-zinc-700" 
                  placeholder="admin@metalblade.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] ml-2">Secure Passcode</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
                <input 
                  type="password" 
                  required
                  autoComplete="current-password"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl pl-12 pr-6 py-4 text-sm font-bold text-white focus:outline-none focus:border-purple-500 transition-all placeholder:text-zinc-700" 
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-3 bg-red-600/10 border border-red-600/30 p-4 rounded-xl text-red-500"
              >
                <AlertCircle size={18} className="shrink-0" />
                <span className="text-[10px] font-black uppercase tracking-wider">{error}</span>
              </motion.div>
            )}

            <button 
              type="submit" 
              disabled={loading}
              className="w-full py-5 bg-purple-600 text-white font-black uppercase text-xs tracking-[0.3em] rounded-2xl hover:bg-purple-500 transition-all shadow-[0_10px_30px_rgba(168,85,247,0.3)] flex items-center justify-center gap-3"
            >
              {loading ? (
                <>
                  <RefreshCcw size={18} className="animate-spin" />
                  Decrypting...
                </>
              ) : (
                <>
                  <LogIn size={18} />
                  Establish Link
                </>
              )}
            </button>
          </form>
        </div>

        <div className="text-center mt-12">
          <p className="text-[8px] font-bold text-zinc-700 uppercase tracking-widest">Authorized Personnel Only • Digital Integrity Guaranteed</p>
        </div>
      </motion.div>
    </div>
  );
}
