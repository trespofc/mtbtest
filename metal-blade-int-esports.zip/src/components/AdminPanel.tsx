import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Layout, 
  Trophy, 
  Palette, 
  Search, 
  Megaphone, 
  LogOut, 
  ExternalLink, 
  Plus, 
  Trash2, 
  ArrowUp, 
  ArrowDown, 
  ArrowRight,
  Eye, 
  EyeOff, 
  Save, 
  Upload,
  Cpu,
  RefreshCcw,
  CheckCircle2,
  AlertCircle,
  Wand2,
  Users,
  MessageSquare,
  Heart,
  Network,
  Flame
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Section {
  id: string;
  type: 'normal' | 'tournament';
  title: string;
  visible: boolean;
  order: number;
  content?: string; // HTML or text for normal
  filter?: string; // Status filter for tournament
}

interface Tournament {
  id: string;
  title: string;
  description: string;
  img: string;
  championBanner: string;
  showChampion: boolean;
  status: 'LIVE' | 'UPCOMING' | 'ENDED';
  prize: string;
  teams: string;
  fee: string;
}

interface Analytics {
  totalViews: number;
  uniqueIps: string[];
}

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // Core Data State
  const [sections, setSections] = useState<Section[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [theme, setTheme] = useState({ type: 'dark', primary: '#b026ff', secondary: '#c026d3', showChampionShowcase: true, logo: '' });
  const [seo, setSeo] = useState({ title: '', description: '', tags: [] as string[], verificationHeader: '', analyticsId: '' });
  const [ads, setAds] = useState({ header: '', sidebar: '', footer: '' });
  const [analytics, setAnalytics] = useState<Analytics>({ totalViews: 0, uniqueIps: [] });
  const [team, setTeam] = useState<any[]>([]);
  const [socials, setSocials] = useState<any[]>([]);
  const [stats, setStats] = useState<any[]>([]);
  const [sponsors, setSponsors] = useState<string[]>([]);
  const [globalContent, setGlobalContent] = useState<any>({});
  const [nav, setNav] = useState<any[]>([]);

  // UI State for Forms
  const [newTournament, setNewTournament] = useState<Partial<Tournament>>({ status: 'UPCOMING' });
  const [aiPrompt, setAiPrompt] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const respSections = await fetch('/api/sections');
      setSections(await respSections.json());

      const respTournaments = await fetch('/api/tournaments');
      setTournaments(await respTournaments.json());

      const respTheme = await fetch('/api/theme');
      setTheme(await respTheme.json());

      const respSeo = await fetch('/api/seo');
      setSeo(await respSeo.json());

      const respAds = await fetch('/api/ads');
      setAds(await respAds.json());

      const respAnalytics = await fetch('/api/analytics');
      setAnalytics(await respAnalytics.json());

      const respTeam = await fetch('/api/team');
      setTeam(await respTeam.json());

      const respSocials = await fetch('/api/socials');
      setSocials(await respSocials.json());

      const respStats = await fetch('/api/stats');
      setStats(await respStats.json());

      const respSponsors = await fetch('/api/sponsors');
      setSponsors(await respSponsors.json());

      const respContent = await fetch('/api/content');
      setGlobalContent(await respContent.json());

      const respNav = await fetch('/api/nav');
      setNav(await respNav.json());
    } catch (e) {
      showToast('Critical data load failure. Re-check server connectivity.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleSave = async (endpoint: string, data: any, message: string = 'Configuration Published Successfully!') => {
    setLoading(true);
    try {
      const resp = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (resp.ok) showToast(message);
      else throw new Error();
    } catch (e) {
      showToast('Write Operation Denied. Internal Server Error.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (file: File): Promise<string> => {
    const formData = new FormData();
    formData.append('file', file);
    const resp = await fetch('/api/upload', {
      method: 'POST',
      body: formData,
    });
    const data = await resp.json();
    return data.url;
  };

  const generateAIPalette = async () => {
    setLoading(true);
    try {
      // Mocking AI analyzer - in production this would call a vision model or direct palette extractor
      const mockAccents = ['#ff00ea', '#7000ff', '#00d4ff'];
      const chosen = mockAccents[Math.floor(Math.random() * mockAccents.length)];
      setTheme({ ...theme, primary: chosen });
      showToast('AI analyzed brand assets and proposed a matching palette');
    } finally {
      setLoading(false);
    }
  };

  const generateAIContent = async () => {
    if (!aiPrompt) return showToast('Please enter seed parameters for content generation', 'error');
    setLoading(true);
    try {
      // In a real app, this would fetch from /api/ai
      setNewTournament({
        ...newTournament,
        description: `Forged in the silicon valley of tactical warfare, this match brings together ${aiPrompt}. Prepare for absolute dominance.`,
      });
      showToast('AI generated a custom catchphrase for your event.');
    } finally {
      setLoading(false);
    }
  };

  // Sections Logic
  const moveSection = (index: number, direction: 'up' | 'down') => {
    const newSections = [...sections];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newSections.length) return;
    
    [newSections[index], newSections[targetIndex]] = [newSections[targetIndex], newSections[index]];
    
    // Update order prop
    newSections.forEach((s, idx) => s.order = idx);
    setSections(newSections);
    handleSave('/api/sections', newSections, 'Layout Order Re-synched');
  };

  const deleteSection = (id: string) => {
    const filtered = sections.filter(s => s.id !== id);
    setSections(filtered);
    handleSave('/api/sections', filtered, 'Module Purged');
  };

  const addNewSection = () => {
    const id = 'section_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
    const newS: Section = { id, type: 'normal', title: 'New Layout Block', visible: true, order: sections.length, content: '' };
    setSections([...sections, newS]);
    handleSave('/api/sections', [...sections, newS]);
  };

  // Tournament Logic
  const createTournament = async () => {
    const id = 'tourn_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
    const finalObj = { ...newTournament, id };
    const list = [...tournaments, finalObj as Tournament];
    setTournaments(list);
    await handleSave('/api/tournaments', list, 'Tournament Instance Created');
    setNewTournament({ status: 'UPCOMING' });
  };

  const updateTournament = async (id: string, updates: Partial<Tournament>) => {
    const list = tournaments.map(t => t.id === id ? { ...t, ...updates } : t);
    setTournaments(list);
    await handleSave('/api/tournaments', list, 'Match Logic Updated');
  };

  const tabs = [
    { name: 'Home Layout', icon: Layout },
    { name: 'Matches', icon: Trophy },
    { name: 'Branding', icon: Palette },
    { name: 'SEO & Index', icon: Search },
    { name: 'Advertisements', icon: Megaphone },
    { name: 'Analytics', icon: BarChart3 },
    { name: 'Team', icon: Users },
    { name: 'Stats', icon: BarChart3 },
    { name: 'Socials', icon: MessageSquare },
    { name: 'Sponsors', icon: Heart },
    { name: 'Navigation', icon: Layout },
    { name: 'Global Content', icon: Layout },
  ];

  return (
    <div className="flex min-h-screen bg-[#050510] text-zinc-300 font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-[#0a0a1a] border-r border-zinc-800 flex flex-col shrink-0">
        <div className="p-8 border-b border-zinc-800">
          <div className="flex items-center gap-2 mb-2">
            <div className="p-2 bg-purple-600/20 rounded-lg">
              <Cpu className="text-purple-500 w-6 h-6 border border-purple-500/30" />
            </div>
            <h1 className="font-black italic text-xl tracking-widest text-white">METAL<span className="text-purple-500">BLADE</span></h1>
          </div>
          <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Command Center v1.0</p>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {tabs.map((tab, i) => (
            <button
              key={`admin-tab-${i}`}
              onClick={() => setActiveTab(i)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-black uppercase text-[10px] tracking-widest ${
                activeTab === i 
                  ? 'bg-purple-600/10 text-purple-400 border border-purple-600/30 shadow-[0_4px_15px_rgba(168,85,247,0.1)]' 
                  : 'hover:bg-zinc-800/50 hover:text-zinc-100'
              }`}
            >
              <tab.icon size={16} />
              {tab.name}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-zinc-800">
          <button className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-600/10 text-red-500 border border-red-600/20 hover:bg-red-600/20 transition-all font-black uppercase text-[10px] tracking-widest">
            <LogOut size={16} />
            Secure Logout
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 h-screen overflow-y-auto">
        {/* Top Header */}
        <header className="sticky top-0 z-40 bg-[#050510]/80 backdrop-blur-md border-b border-zinc-800 h-20 px-10 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-black uppercase tracking-[0.3em] text-white flex items-center gap-3">
              {tabs[activeTab].name}
              {loading && <RefreshCcw size={14} className="animate-spin text-purple-500" />}
            </h2>
          </div>
          <div className="flex items-center gap-4">
            <a href="/" target="_blank" className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-xs font-bold hover:bg-zinc-800 transition-all">
              <ExternalLink size={14} /> View Live Site
            </a>
            <div className="h-8 w-[1px] bg-zinc-800 mx-2"></div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-xs font-black text-white italic">Administrator</p>
                <p className="text-[10px] text-zinc-500 uppercase tracking-widest">Active Session</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-full border border-white/10 shadow-lg"></div>
            </div>
          </div>
        </header>

        {/* Dynamic Tab Body */}
        <div className="p-10 max-w-6xl">
          {activeTab === 0 && (
            /* Universal Page Builder */
            <div className="space-y-8">
              <div className="flex justify-between items-center bg-[#0a0a1a] p-6 rounded-[2rem] border border-zinc-800">
                <div>
                  <h3 className="text-xl font-black italic text-white uppercase tracking-tighter">Homepage Structure</h3>
                  <p className="text-xs text-zinc-500 mt-1">Append and re-order layout modules dynamically.</p>
                </div>
                <button onClick={addNewSection} className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-purple-500 transition-all shadow-[0_4px_20px_rgba(168,85,247,0.3)]">
                  <Plus size={16} /> New Module
                </button>
              </div>

              <div className="space-y-4">
                {sections.sort((a,b) => a.order - b.order).map((section, idx) => (
                  <div key={section.id} className="bg-[#0a0a1a] rounded-2xl border border-zinc-800 p-6 flex items-start gap-8 group">
                    <div className="flex flex-col gap-2 mt-2">
                      <button onClick={() => moveSection(idx, 'up')} className="p-2 hover:text-purple-400 transition-colors bg-zinc-900 rounded-lg"><ArrowUp size={16}/></button>
                      <button onClick={() => moveSection(idx, 'down')} className="p-2 hover:text-purple-400 transition-colors bg-zinc-900 rounded-lg"><ArrowDown size={16}/></button>
                    </div>

                    <div className="flex-1 grid grid-cols-12 gap-6">
                      <div className="col-span-8">
                        <div className="flex items-center gap-4 mb-4">
                          <input 
                            type="text" 
                            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-bold text-white focus:outline-none focus:border-purple-500 transition-all font-sans"
                            value={section.title}
                            onChange={(e) => {
                              const newS = [...sections];
                              newS[idx].title = e.target.value;
                              setSections(newS);
                            }}
                          />
                          <select 
                            className="bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-[10px] font-black uppercase text-zinc-400"
                            value={section.type}
                            onChange={(e) => {
                              const newS = [...sections];
                              newS[idx].type = e.target.value as any;
                              setSections(newS);
                            }}
                          >
                            <option value="normal">Normal Section</option>
                            <option value="tournament">Tournament Grid</option>
                          </select>
                        </div>
                        
                        {section.type === 'normal' ? (
                          <textarea 
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-6 py-6 text-xs text-zinc-400 h-40 focus:outline-none focus:border-purple-500 transition-all resize-none font-mono"
                            placeholder="Insert standard text or RAW HTML injection block..."
                            value={section.content}
                            onChange={(e) => {
                              const newS = [...sections];
                              newS[idx].content = e.target.value;
                              setSections(newS);
                            }}
                          />
                        ) : (
                          <div className="bg-zinc-900/50 rounded-2xl p-6 border border-zinc-800 border-dashed">
                             <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-4">Filtering Rules</p>
                             <div className="flex items-center gap-2">
                                <label className="text-xs text-zinc-300">Display entries labeled as:</label>
                                <select 
                                  className="bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-[10px] font-black text-white uppercase"
                                  value={section.filter}
                                  onChange={(e) => {
                                    const newS = [...sections];
                                    newS[idx].filter = e.target.value;
                                    setSections(newS);
                                  }}
                                >
                                  <option value="LIVE">Live Battles</option>
                                  <option value="UPCOMING">Upcoming Matches</option>
                                  <option value="ENDED">Past Victories</option>
                                </select>
                             </div>
                          </div>
                        )}
                      </div>

                      <div className="col-span-4 flex flex-col justify-between items-end gap-4 py-2">
                        <div className="flex flex-col items-end gap-3">
                          <label className="flex items-center gap-3 cursor-pointer group/toggle">
                            <span className="text-[10px] font-black uppercase text-zinc-500 group-hover/toggle:text-zinc-300 transition-colors">Visible</span>
                            <button 
                              onClick={() => {
                                const newS = [...sections];
                                newS[idx].visible = !newS[idx].visible;
                                setSections(newS);
                              }}
                              className={`w-12 h-6 rounded-full transition-all relative ${section.visible ? 'bg-purple-600' : 'bg-zinc-800'}`}
                            >
                              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${section.visible ? 'right-1' : 'left-1'}`} />
                            </button>
                          </label>
                        </div>
                        
                        <div className="flex gap-2">
                          <button onClick={() => deleteSection(section.id)} className="p-3 bg-red-600/10 text-red-500 border border-red-600/20 rounded-xl hover:bg-red-600 hover:text-white transition-all"><Trash2 size={16} /></button>
                          <button onClick={() => handleSave('/api/sections', sections)} className="px-6 py-3 bg-zinc-900 text-white rounded-xl border border-zinc-800 hover:border-zinc-100 transition-all flex items-center gap-2 font-black uppercase text-[10px] tracking-widest"><Save size={16} /> Save Changes</button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 1 && (
            /* Tournament Segment Controller */
            <div className="space-y-10">
              <div className="grid grid-cols-2 gap-8">
                 <div className="bg-[#0a0a1a] p-10 rounded-[2.5rem] border border-zinc-800 space-y-6">
                    <h3 className="text-xl font-black italic text-white uppercase flex items-center gap-3"><Trophy className="text-purple-500" /> New Contest Builder</h3>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-2">Match Title</label>
                        <input 
                          type="text" 
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-sm font-bold text-white focus:outline-none focus:border-purple-500 transition-all"
                          placeholder="e.g. METAL BLADE SPRING CUP 2026"
                          value={newTournament.title || ''}
                          onChange={(e) => setNewTournament({ ...newTournament, title: e.target.value })}
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-2">Match Description</label>
                        <textarea 
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-sm font-bold text-white h-32 focus:outline-none focus:border-purple-500 transition-all resize-none"
                          placeholder="Summarize the event parameters and history..."
                          value={newTournament.description || ''}
                          onChange={(e) => setNewTournament({ ...newTournament, description: e.target.value })}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                         <div>
                           <label className="block text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-2">Display Status</label>
                           <select 
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-xs font-black uppercase text-white"
                            value={newTournament.status}
                            onChange={(e) => setNewTournament({ ...newTournament, status: e.target.value as any })}
                           >
                             <option value="LIVE">Live</option>
                             <option value="UPCOMING">Upcoming</option>
                             <option value="ENDED">Ended</option>
                           </select>
                         </div>
                         <div>
                            <label className="block text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-2">Prize Pool</label>
                            <input 
                            type="text" 
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-sm font-bold text-white placeholder:text-zinc-700" 
                            placeholder="e.g. $5,000 USD"
                            value={newTournament.prize || ''}
                            onChange={(e) => setNewTournament({ ...newTournament, prize: e.target.value })}
                            />
                         </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                         <div>
                           <label className="block text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-2">Participating Teams</label>
                           <input 
                            type="text" 
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-sm font-bold text-white" 
                            placeholder="e.g. 16 Elite Teams"
                            value={newTournament.teams || ''}
                            onChange={(e) => setNewTournament({ ...newTournament, teams: e.target.value })}
                            />
                         </div>
                         <div>
                            <label className="block text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-2">Entry Fee</label>
                            <input 
                            type="text" 
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-sm font-bold text-white" 
                            placeholder="e.g. FREE"
                            value={newTournament.fee || ''}
                            onChange={(e) => setNewTournament({ ...newTournament, fee: e.target.value })}
                            />
                         </div>
                      </div>
                    </div>
                 </div>

                 <div className="bg-[#0a0a1a] p-10 rounded-[2.5rem] border border-zinc-800 space-y-8 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xl font-black italic text-white uppercase flex items-center gap-3"><Upload className="text-purple-500" /> Digital Assets</h3>
                      
                      <div className="mt-8 space-y-6">
                        <div>
                          <label className="block text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-4">Cover Banner Artwork</label>
                          <div className="flex items-center gap-6">
                            <div className="w-32 h-20 bg-zinc-900 rounded-xl border border-zinc-800 overflow-hidden flex-shrink-0 flex items-center justify-center">
                              {newTournament.img ? <img src={newTournament.img} className="w-full h-full object-cover" /> : <EyeOff size={20} className="opacity-20"/>}
                            </div>
                            <label className="flex-1 cursor-pointer">
                              <input type="file" className="hidden" onChange={async (e) => {
                                 if (e.target.files) {
                                  const url = await handleFileUpload(e.target.files[0]);
                                  setNewTournament({ ...newTournament, img: url });
                                 }
                              }} />
                              <div className="bg-zinc-900 border border-zinc-800 rounded-xl px-6 py-4 text-center hover:border-purple-500 transition-all">
                                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Browse Asset...</span>
                              </div>
                            </label>
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-4">Champion Victory Banner</label>
                          <div className="flex items-center gap-6">
                            <div className="w-32 h-20 bg-zinc-900 rounded-xl border border-zinc-800 overflow-hidden flex-shrink-0 flex items-center justify-center">
                              {newTournament.championBanner ? <img src={newTournament.championBanner} className="w-full h-full object-cover" /> : <Trophy size={20} className="opacity-20"/>}
                            </div>
                            <label className="flex-1 cursor-pointer">
                              <input type="file" className="hidden" onChange={async (e) => {
                                 if (e.target.files) {
                                  const url = await handleFileUpload(e.target.files[0]);
                                  setNewTournament({ ...newTournament, championBanner: url });
                                 }
                              }} />
                              <div className="bg-zinc-900 border border-zinc-800 rounded-xl px-6 py-4 text-center hover:border-purple-500 transition-all">
                                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Browse Artwork...</span>
                              </div>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-600/5 border border-purple-500/20 p-8 rounded-3xl space-y-4">
                       <div className="flex items-center justify-between">
                          <span className="text-[10px] font-black uppercase text-purple-400 tracking-[0.2em]">Smart Intelligence Helper</span>
                          <Wand2 size={16} className="text-purple-500" />
                       </div>
                       <div className="flex gap-2">
                         <input 
                           type="text" 
                           className="flex-1 bg-black/40 border border-purple-900/30 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-purple-500" 
                           placeholder="Describe event vibe (e.g. aggressive, summer, elite)..."
                           value={aiPrompt}
                           onChange={(e) => setAiPrompt(e.target.value)}
                         />
                         <button onClick={generateAIContent} className="px-6 py-3 bg-purple-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-purple-500 transition-all">Generate</button>
                       </div>
                    </div>

                    <button onClick={createTournament} className="w-full py-6 bg-white text-black font-black uppercase tracking-[0.3em] rounded-2xl hover:bg-purple-400 hover:text-white transition-all shadow-[0_10px_40px_rgba(168,85,247,0.2)]">Publish Tournament Entity</button>
                 </div>
              </div>

              <div className="space-y-4">
                 <h3 className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.4em] mb-6 border-b border-zinc-800 pb-4">Active Roster Database</h3>
                 <div className="grid grid-cols-1 gap-4">
                  {tournaments.map((t) => (
                    <div key={t.id} className="bg-[#0a0a1a] rounded-[1.5rem] border border-zinc-800 p-6 flex items-center justify-between group hover:border-zinc-600 transition-all">
                      <div className="flex items-center gap-6">
                        <div className="w-20 h-14 rounded-lg overflow-hidden bg-zinc-900 border border-zinc-800">
                          <img src={t.img} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <span className={`text-[8px] font-black uppercase tracking-[0.2em] px-2 py-0.5 rounded ${t.status === 'LIVE' ? 'bg-red-500/10 text-red-500' : t.status === 'UPCOMING' ? 'bg-purple-500/10 text-purple-500' : 'bg-zinc-800 text-zinc-400'}`}>
                            {t.status}
                          </span>
                          <h4 className="text-white font-black uppercase italic mt-1 tracking-tight">{t.title}</h4>
                        </div>
                      </div>

                      <div className="flex items-center gap-12">
                        <div className="flex items-center gap-3">
                           <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Show Winner</span>
                           <button 
                            disabled={!t.championBanner}
                            onClick={() => updateTournament(t.id, { showChampion: !t.showChampion })}
                            className={`w-12 h-6 rounded-full transition-all relative ${t.showChampion ? 'bg-purple-600' : 'bg-zinc-800'} ${!t.championBanner ? 'opacity-20 cursor-not-allowed' : ''}`}
                           >
                             <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${t.showChampion ? 'right-1' : 'left-1'}`} />
                           </button>
                        </div>
                        
                        <div className="flex gap-2">
                          <button className="p-3 bg-zinc-800 text-zinc-400 rounded-xl hover:bg-zinc-700 transition-all"><Eye size={16}/></button>
                          <button onClick={() => {
                             const list = tournaments.filter(it => it.id !== t.id);
                             setTournaments(list);
                             handleSave('/api/tournaments', list);
                          }} className="p-3 bg-red-600/10 text-red-500 border border-red-600/20 rounded-xl hover:bg-red-600 hover:text-white transition-all"><Trash2 size={16}/></button>
                        </div>
                      </div>
                    </div>
                  ))}
                 </div>
              </div>
            </div>
          )}

          {activeTab === 2 && (
            /* Visual Theme & AI Branding */
            <div className="grid grid-cols-2 gap-10">
               <div className="bg-[#0a0a1a] p-12 rounded-[3rem] border border-zinc-800 space-y-10">
                  <div>
                    <h3 className="text-xl font-black italic text-white uppercase mb-2">Atmosphere Profile</h3>
                    <p className="text-xs text-zinc-500 mb-8">Select the core visual canvas for the end-user.</p>
                    
                    <div className="grid grid-cols-2 gap-4">
                       <button 
                        onClick={() => setTheme({ ...theme, type: 'dark' })}
                        className={`p-6 rounded-2xl border transition-all text-center space-y-3 ${theme.type === 'dark' ? 'border-purple-500 bg-purple-500/10' : 'border-zinc-800 bg-zinc-900 group hover:border-zinc-600'}`}
                       >
                         <div className="w-12 h-12 bg-black mx-auto rounded-lg border border-purple-500/30 flex items-center justify-center text-purple-400 text-xs font-black">NIGHT</div>
                         <p className="text-[10px] font-black uppercase tracking-widest">Dark Onyx</p>
                       </button>

                       <button 
                        onClick={() => setTheme({ ...theme, type: 'white' })}
                        className={`p-6 rounded-2xl border transition-all text-center space-y-3 ${theme.type === 'white' ? 'border-purple-500 bg-purple-500/10' : 'border-zinc-800 bg-zinc-900 group hover:border-zinc-600'}`}
                       >
                         <div className="w-12 h-12 bg-white mx-auto rounded-lg border border-zinc-200 flex items-center justify-center text-zinc-400 text-xs font-black">DAY</div>
                         <p className="text-[10px] font-black uppercase tracking-widest">Crystal White</p>
                       </button>
                    </div>
                  </div>

                  <div>
                     <h3 className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.3em] mb-6">Accent Color Palette</h3>
                     <div className="space-y-6">
                        <div className="flex items-center gap-6">
                           <div className="w-16 h-16 rounded-2xl overflow-hidden border border-zinc-800" style={{ backgroundColor: theme.primary }}></div>
                           <div className="flex-1">
                              <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Primary Hex</label>
                              <div className="flex gap-2">
                                <input 
                                  type="text" 
                                  className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs font-mono text-zinc-400 focus:outline-none focus:border-purple-500" 
                                  value={theme.primary}
                                  onChange={(e) => setTheme({ ...theme, primary: e.target.value })}
                                />
                                <button onClick={generateAIPalette} className="p-3 bg-purple-600 text-white rounded-xl hover:bg-purple-500 transition-all" title="Extract Palette via AI"><Wand2 size={16}/></button>
                              </div>
                           </div>
                        </div>

                        <div className="flex items-center gap-6">
                           <div className="w-16 h-16 rounded-2xl overflow-hidden border border-zinc-800" style={{ backgroundColor: theme.secondary }}></div>
                           <div className="flex-1">
                              <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Secondary Accent</label>
                              <input 
                                type="text" 
                                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs font-mono text-zinc-400 focus:outline-none focus:border-purple-500" 
                                value={theme.secondary}
                                onChange={(e) => setTheme({ ...theme, secondary: e.target.value })}
                              />
                           </div>
                        </div>
                     </div>
                  </div>

                  <button onClick={() => handleSave('/api/theme', theme)} className="w-full py-5 bg-zinc-900 border border-zinc-800 rounded-2xl text-white font-black uppercase text-[10px] tracking-widest hover:border-zinc-400 transition-all"><Save size={16} className="inline mr-2"/> Commit Theme Variable</button>
               </div>

               <div className="space-y-10">
                  <div className="bg-[#0a0a1a] p-12 rounded-[3rem] border border-zinc-800">
                    <h3 className="text-xl font-black italic text-white uppercase mb-8">Brand Typography Logo</h3>
                    <div className="aspect-[3/1] bg-black rounded-3xl border border-zinc-800 flex items-center justify-center p-8 relative overflow-hidden group">
                       <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent"></div>
                       {theme.logo ? <img src={theme.logo} className="h-full object-contain relative z-10" /> : <p className="text-zinc-500 text-sm italic">No Vector Asset Synchronized</p>}
                       <label className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity backdrop-blur-sm">
                          <input type="file" className="hidden" onChange={async (e) => {
                             if (e.target.files) {
                              const url = await handleFileUpload(e.target.files[0]);
                              setTheme({ ...theme, logo: url });
                             }
                          }} />
                          <span className="bg-white text-black px-6 py-3 rounded-xl font-black uppercase text-[10px] tracking-widest flex items-center gap-2"><Upload size={14}/> Sync New Logo</span>
                       </label>
                    </div>
                  </div>

                  <div className="bg-[#0a0a1a] p-10 rounded-[3rem] border border-zinc-800">
                    <div className="flex items-center justify-between mb-2">
                       <h3 className="text-sm font-black italic text-white uppercase">Champion Showcase</h3>
                       <button 
                        onClick={() => setTheme({ ...theme, showChampionShowcase: !theme.showChampionShowcase })}
                        className={`w-12 h-6 rounded-full transition-all relative ${theme.showChampionShowcase ? 'bg-purple-600' : 'bg-zinc-800'}`}
                       >
                         <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${theme.showChampionShowcase ? 'right-1' : 'left-1'}`} />
                       </button>
                    </div>
                    <p className="text-[10px] text-zinc-500 leading-relaxed uppercase font-bold pr-12">If activated, the homepage will render a dedicated visual row exclusively featuring recently ended winners.</p>
                  </div>
               </div>
            </div>
          )}

          {activeTab === 3 && (
            /* SEO & Indexing */
            <div className="space-y-10">
               <div className="grid grid-cols-2 gap-10">
                  <div className="bg-[#0a0a1a] p-12 rounded-[3.5rem] border border-zinc-800 space-y-8">
                     <h3 className="text-xl font-black italic text-white uppercase"><Search size={24} className="inline mr-3 text-purple-500"/> Crawl Optimization</h3>
                     
                     <div className="space-y-6">
                        <div>
                           <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-3">Global Site Title Alias</label>
                           <input 
                            type="text" 
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-sm font-bold text-white focus:outline-none focus:border-purple-500" 
                            placeholder="e.g. Metal Blade Int Esports | Professional Free Fire"
                            value={seo.title}
                            onChange={(e) => setSeo({ ...seo, title: e.target.value })}
                           />
                        </div>

                        <div>
                           <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-3">Meta Perspective Description</label>
                           <textarea 
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-xs leading-relaxed text-zinc-400 h-32 focus:outline-none focus:border-purple-500 resize-none" 
                            placeholder="A concise summary of site content for search engine snippets..."
                            value={seo.description}
                            onChange={(e) => setSeo({ ...seo, description: e.target.value })}
                           />
                        </div>

                        <div>
                           <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-3">Search Meta Keywords (Comma Separated)</label>
                           <input 
                            type="text" 
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-xs font-mono text-zinc-400 focus:outline-none focus:border-purple-500" 
                            placeholder="esports, gaming, bangladesh, FF, scrims..."
                            value={seo.tags.join(', ')}
                            onChange={(e) => setSeo({ ...seo, tags: e.target.value.split(',').map(s => s.trim()) })}
                           />
                        </div>
                     </div>
                  </div>

                  <div className="bg-[#0a0a1a] p-12 rounded-[3.5rem] border border-zinc-800 flex flex-col justify-between">
                     <div className="space-y-8">
                        <h3 className="text-xl font-black italic text-white uppercase"><CheckCircle2 size={24} className="inline mr-3 text-purple-500"/> Verification Suite</h3>
                        
                        <div className="space-y-6">
                           <div>
                              <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-3">Google Console HTML Tag Verification</label>
                              <input 
                               type="text" 
                               className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-[10px] font-mono text-purple-400 focus:outline-none focus:border-purple-500" 
                               placeholder="<meta name='google-site-verification' content='...' />"
                               value={seo.verificationHeader}
                               onChange={(e) => setSeo({ ...seo, verificationHeader: e.target.value })}
                              />
                           </div>

                           <div>
                              <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-3">Analytics G-ID Script Node</label>
                              <input 
                               type="text" 
                               className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-[10px] font-mono text-purple-400 focus:outline-none focus:border-purple-500" 
                               placeholder="G-XXXXXXXXX"
                               value={seo.analyticsId}
                               onChange={(e) => setSeo({ ...seo, analyticsId: e.target.value })}
                              />
                           </div>
                        </div>
                     </div>

                     <div className="pt-8 space-y-4">
                        <button onClick={() => window.open('/sitemap.xml', '_blank')} className="w-full py-5 border border-purple-500/30 bg-purple-500/5 rounded-2xl text-purple-400 font-black uppercase text-[10px] tracking-widest hover:bg-purple-500 hover:text-white transition-all flex items-center justify-center gap-3"><ArrowRight size={16}/> Instant Sitemap Trigger</button>
                        <button onClick={() => handleSave('/api/seo', seo)} className="w-full py-5 bg-white text-black font-black uppercase text-[10px] tracking-widest rounded-2xl hover:bg-purple-400 hover:text-white transition-all shadow-[0_10px_35px_rgba(255,255,255,0.1)]">Sync Search Meta Integrity</button>
                     </div>
                  </div>
               </div>
            </div>
          )}

          {activeTab === 4 && (
            /* Ad Script Manager */
            <div className="space-y-10">
              <div className="bg-[#0a0a1a] p-12 rounded-[3.5rem] border border-zinc-800 space-y-10">
                 <div className="flex items-center gap-4 border-b border-zinc-800 pb-8 mb-4">
                    <div className="p-4 bg-green-500/10 rounded-2xl border border-green-500/30 text-green-500"><Megaphone size={32} /></div>
                    <div>
                       <h3 className="text-2xl font-black italic text-white uppercase tracking-tighter leading-none">Net Monetization Console</h3>
                       <p className="text-xs text-zinc-500 mt-2">Paste raw JS/HTML script snippets for network advertisement blocks.</p>
                    </div>
                 </div>

                 <div className="grid grid-cols-1 gap-10">
                    <div>
                       <label className="flex items-center gap-3 text-[10px] font-black text-green-500 uppercase tracking-widest mb-4">
                          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> Header Banner Advert Code (728x90)
                       </label>
                       <textarea 
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-3xl px-8 py-8 text-[10px] font-mono text-zinc-500 h-40 focus:outline-none focus:border-green-500 focus:text-zinc-200 transition-all resize-none shadow-inner"
                        placeholder="<ins class='adsbygoogle' ...></ins><script>...</script>"
                        value={ads.header}
                        onChange={(e) => setAds({ ...ads, header: e.target.value })}
                       />
                    </div>

                    <div>
                       <label className="flex items-center gap-3 text-[10px] font-black text-green-500 uppercase tracking-widest mb-4">
                          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> Sidebar Widget Advert (300x250)
                       </label>
                       <textarea 
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-3xl px-8 py-8 text-[10px] font-mono text-zinc-500 h-40 focus:outline-none focus:border-green-500 focus:text-zinc-200 transition-all resize-none shadow-inner"
                        placeholder="Copy paste script provider code here..."
                        value={ads.sidebar}
                        onChange={(e) => setAds({ ...ads, sidebar: e.target.value })}
                       />
                    </div>

                    <div>
                       <label className="flex items-center gap-3 text-[10px] font-black text-green-500 uppercase tracking-widest mb-4">
                          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> Footer Branding Placement Code
                       </label>
                       <textarea 
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-3xl px-8 py-8 text-[10px] font-mono text-zinc-500 h-40 focus:outline-none focus:border-green-500 focus:text-zinc-200 transition-all resize-none shadow-inner"
                        placeholder="Anchor script logic for footer layer..."
                        value={ads.footer}
                        onChange={(e) => setAds({ ...ads, footer: e.target.value })}
                       />
                    </div>
                 </div>

                 <button onClick={() => handleSave('/api/ads', ads)} className="w-full py-6 bg-green-600 text-white font-black uppercase text-xs tracking-[0.3em] rounded-3xl hover:bg-green-500 transition-all shadow-[0_10px_35px_rgba(34,197,94,0.2)]">Execute Site-Wide Script Injection</button>
              </div>
            </div>
          )}

          {activeTab === 5 && (
            /* Analytics Monitoring */
            <div className="space-y-8">
              <div className="grid grid-cols-2 gap-8">
                 <div className="bg-[#0a0a1a] p-12 rounded-[4rem] border border-zinc-800 text-center space-y-4 relative overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent"></div>
                    <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.4em] relative z-10">Total Aggregate Page Views</p>
                    <h4 className="text-8xl font-black italic text-white tracking-widest relative z-10 drop-shadow-[0_0_20px_rgba(255,255,255,0.1)]">{analytics.totalViews.toLocaleString()}</h4>
                    <div className="flex justify-center gap-2 relative z-10">
                       <span className="h-1.5 w-1.5 rounded-full bg-purple-500 animate-bounce"></span>
                       <span className="h-1.5 w-1.5 rounded-full bg-purple-500 animate-bounce [animation-delay:0.2s]"></span>
                       <span className="h-1.5 w-1.5 rounded-full bg-purple-500 animate-bounce [animation-delay:0.4s]"></span>
                    </div>
                 </div>

                 <div className="bg-[#0a0a1a] p-12 rounded-[4rem] border border-zinc-800 text-center space-y-4 relative overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent"></div>
                    <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.4em] relative z-10">Verified Unique Visitors</p>
                    <h4 className="text-8xl font-black italic text-white tracking-widest relative z-10 drop-shadow-[0_0_20px_rgba(255,255,255,0.1)]">{analytics.uniqueIps.length.toLocaleString()}</h4>
                    <p className="text-[10px] font-bold text-indigo-400 relative z-10">Calculated from unique IP handshake clusters.</p>
                 </div>
              </div>

              <div className="bg-[#0a0a1a] p-10 rounded-[3rem] border border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-6">
                   <div className="w-16 h-16 bg-purple-500/10 rounded-2xl flex items-center justify-center border border-purple-500/20 text-purple-500"><AlertCircle size={24}/></div>
                   <div>
                      <h3 className="text-sm font-black italic text-white uppercase tracking-tight">Real-Time Data Handshake</h3>
                      <p className="text-xs text-zinc-500 uppercase font-black tracking-widest mt-1">Status: Fully Operational</p>
                   </div>
                </div>
                <button onClick={fetchData} className="px-10 py-5 bg-white text-black font-black uppercase text-[10px] tracking-widest rounded-2xl hover:bg-purple-500 hover:text-white transition-all shadow-[0_10px_30px_rgba(255,255,255,0.05)] flex items-center gap-3">
                  <RefreshCcw size={16}/> Refresh Live Database Metrics
                </button>
              </div>

              <div className="bg-[#0a0a1a] p-8 rounded-3xl border border-zinc-800 h-96 overflow-hidden relative">
                 <div className="absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-[#0a0a1a] to-transparent z-10 flex items-center px-8">
                    <h3 className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.4em]">Recent Visitor Handshake History</h3>
                 </div>
                 <div className="mt-12 space-y-2 p-4 h-full overflow-y-auto hide-scrollbar font-mono text-[10px] text-zinc-600">
                    {analytics.uniqueIps.map((ip, i) => (
                      <div key={`ip-record-${i}`} className="flex justify-between border-b border-zinc-800/50 py-2">
                        <span>TCP/IP ESTABLISHED FROM:</span>
                        <span className="text-purple-500 font-bold">{ip}</span>
                      </div>
                    ))}
                 </div>
              </div>
            </div>
          )}

          {activeTab === 6 && (
            /* Management Team */
            <div className="space-y-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black italic text-white uppercase tracking-tighter">Management Team</h3>
                <button 
                  onClick={() => {
                    const newTeam = [...team, { name: 'New Member', role: 'Role Name', desc: 'Description...', img: '' }];
                    setTeam(newTeam);
                    handleSave('/api/team', newTeam);
                  }}
                  className="px-6 py-3 bg-purple-600 text-white rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-purple-500 transition-all flex items-center gap-2"
                >
                  <Plus size={16} /> Add Member
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {team.map((m, i) => (
                  <div key={`team-edit-${i}`} className="bg-[#0a0a1a] p-6 rounded-2xl border border-zinc-800 space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="relative group/avatar">
                        <div className="w-16 h-16 bg-zinc-900 rounded-full border border-zinc-800 overflow-hidden flex-shrink-0">
                          <img src={m.img || `https://api.dicebear.com/7.x/initials/svg?seed=${m.name}`} className="w-full h-full object-cover" />
                        </div>
                        <label className="absolute inset-0 bg-black/60 rounded-full opacity-0 group-hover/avatar:opacity-100 flex items-center justify-center cursor-pointer transition-opacity">
                          <input type="file" className="hidden" onChange={async (e) => {
                            if (e.target.files && e.target.files[0]) {
                              const url = await handleFileUpload(e.target.files[0]);
                              const nt = [...team];
                              nt[i].img = url;
                              setTeam(nt);
                              handleSave('/api/team', nt, 'Member Bio-Asset Updated');
                            }
                          }} />
                          <Upload size={14} className="text-white" />
                        </label>
                      </div>
                      <input 
                        type="text" 
                        placeholder="Name" 
                        value={m.name} 
                        onChange={(e) => {
                          const nt = [...team];
                          nt[i].name = e.target.value;
                          setTeam(nt);
                        }}
                        className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2 text-sm text-white" 
                      />
                    </div>
                    <input 
                      type="text" 
                      placeholder="Role" 
                      value={m.role} 
                      onChange={(e) => {
                        const nt = [...team];
                        nt[i].role = e.target.value;
                        setTeam(nt);
                      }}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2 text-xs text-purple-400 font-bold" 
                    />
                    <textarea 
                      placeholder="Description" 
                      value={m.desc} 
                      onChange={(e) => {
                        const nt = [...team];
                        nt[i].desc = e.target.value;
                        setTeam(nt);
                      }}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2 text-xs text-zinc-400 h-20 resize-none" 
                    />
                    <div className="flex gap-2">
                       <button onClick={() => handleSave('/api/team', team)} className="flex-1 py-2 bg-zinc-800 text-xs font-bold rounded-lg hover:bg-zinc-700 transition-all">Save Member</button>
                       <button onClick={() => {
                         const nt = team.filter((_, idx) => idx !== i);
                         setTeam(nt);
                         handleSave('/api/team', nt);
                       }} className="p-2 bg-red-600/10 text-red-500 rounded-lg hover:bg-red-600 hover:text-white transition-all"><Trash2 size={16}/></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 7 && (
            /* Stats Highlights */
            <div className="grid grid-cols-2 gap-8">
              {stats.map((s, i) => (
                <div key={`stat-edit-${i}`} className="bg-[#0a0a1a] p-8 rounded-3xl border border-zinc-800 space-y-4">
                  <div className="flex items-center gap-4">
                    <select 
                      value={s.icon} 
                      onChange={(e) => {
                        const ns = [...stats];
                        ns[i].icon = e.target.value;
                        setStats(ns);
                      }}
                      className="bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value="Trophy">Trophy</option>
                      <option value="Users">Users</option>
                      <option value="Network">Network</option>
                      <option value="Flame">Flame</option>
                    </select>
                    <input 
                      type="text" 
                      placeholder="Label" 
                      value={s.label} 
                      onChange={(e) => {
                        const ns = [...stats];
                        ns[i].label = e.target.value;
                        setStats(ns);
                      }}
                      className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2 text-sm text-white" 
                    />
                  </div>
                  <input 
                    type="text" 
                    placeholder="Value (e.g. 150+)" 
                    value={s.val} 
                    onChange={(e) => {
                      const ns = [...stats];
                      ns[i].val = e.target.value;
                      setStats(ns);
                    }}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2 text-2xl font-black text-purple-500 italic" 
                  />
                  <button onClick={() => handleSave('/api/stats', stats)} className="w-full py-3 bg-zinc-800 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-zinc-700">Save Stat</button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 8 && (
            /* Social Links */
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black italic text-white uppercase tracking-tighter">Social Channels</h3>
                <button 
                  onClick={() => {
                    const ns = [...socials, { platform: 'New Social', link: '#', type: 'Facebook' }];
                    setSocials(ns);
                    handleSave('/api/socials', ns);
                  }}
                  className="px-6 py-3 bg-purple-600 text-white rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-purple-500 transition-all flex items-center gap-2"
                >
                  <Plus size={16} /> Add Link
                </button>
              </div>
              <div className="grid grid-cols-1 gap-4">
                {socials.map((s, i) => (
                  <div key={`social-edit-${i}`} className="bg-[#0a0a1a] p-6 rounded-2xl border border-zinc-800 flex items-center gap-6">
                    <select 
                      value={s.type} 
                      onChange={(e) => {
                        const ns = [...socials];
                        ns[i].type = e.target.value;
                        setSocials(ns);
                      }}
                      className="bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white"
                    >
                      <option value="Facebook">Facebook</option>
                      <option value="Youtube">Youtube</option>
                      <option value="Instagram">Instagram</option>
                      <option value="MessageSquare">Discord</option>
                      <option value="Play">TikTok</option>
                    </select>
                    <input 
                      type="text" 
                      placeholder="Display Name" 
                      value={s.platform} 
                      onChange={(e) => {
                        const ns = [...socials];
                        ns[i].platform = e.target.value;
                        setSocials(ns);
                      }}
                      className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-bold text-white" 
                    />
                    <input 
                      type="text" 
                      placeholder="URL" 
                      value={s.link} 
                      onChange={(e) => {
                        const ns = [...socials];
                        ns[i].link = e.target.value;
                        setSocials(ns);
                      }}
                      className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-zinc-500" 
                    />
                    <div className="flex gap-2">
                       <button onClick={() => handleSave('/api/socials', socials)} className="p-3 bg-zinc-800 text-zinc-400 rounded-xl hover:text-white transition-all"><Save size={16}/></button>
                       <button onClick={() => {
                         const ns = socials.filter((_, idx) => idx !== i);
                         setSocials(ns);
                         handleSave('/api/socials', ns);
                       }} className="p-3 bg-red-600/10 text-red-500 rounded-xl hover:bg-red-600 hover:text-white transition-all"><Trash2 size={16}/></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 9 && (
            /* Sponsors */
            <div className="space-y-8">
              <div className="bg-[#0a0a1a] p-10 rounded-[3rem] border border-zinc-800">
                <h3 className="text-xl font-black italic text-white uppercase mb-8">Scroll Sponsors</h3>
                <div className="space-y-4">
                  {sponsors.map((s, i) => (
                    <div key={`sponsor-edit-${i}`} className="flex gap-4">
                      <input 
                        type="text" 
                        value={s} 
                        onChange={(e) => {
                          const ns = [...sponsors];
                          ns[i] = e.target.value;
                          setSponsors(ns);
                        }}
                        className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-6 py-4 text-sm font-black uppercase text-white tracking-widest" 
                      />
                      <button onClick={() => {
                        const ns = sponsors.filter((_, idx) => idx !== i);
                        setSponsors(ns);
                        handleSave('/api/sponsors', ns);
                      }} className="p-4 bg-red-600/10 text-red-500 border border-red-600/20 rounded-xl hover:bg-red-600 hover:text-white transition-all"><Trash2 size={16}/></button>
                    </div>
                  ))}
                  <div className="flex gap-4 mt-6">
                    <button 
                      onClick={() => setSponsors([...sponsors, 'NEW SPONSOR'])}
                      className="flex-1 py-4 border-2 border-dashed border-zinc-800 rounded-xl text-zinc-500 font-bold hover:border-purple-500 hover:text-purple-500 transition-all flex items-center justify-center gap-2"
                    >
                      <Plus size={16} /> Insert New Placeholder
                    </button>
                    <button onClick={() => handleSave('/api/sponsors', sponsors)} className="px-10 py-4 bg-purple-600 text-white rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-purple-500 transition-all flex items-center gap-2"><Save size={16} /> Publish Partner List</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 11 && (
            /* Global Content Settings */
            <div className="space-y-10">
              <div className="bg-[#0a0a1a] p-10 rounded-[3rem] border border-zinc-800">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-xl font-black italic text-white uppercase tracking-tighter">Homepage Text & Branding</h3>
                  <button onClick={() => handleSave('/api/content', globalContent)} className="px-10 py-4 bg-purple-600 text-white rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-purple-500 transition-all flex items-center gap-2"><Save size={16} /> Save Global Text</button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <h4 className="text-[10px] font-black text-purple-500 uppercase tracking-widest border-b border-zinc-800 pb-2">Hero Section</h4>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Platform Name (Part 1)</label>
                        <input 
                          type="text" 
                          value={globalContent.heroTitleFirst} 
                          onChange={(e) => setGlobalContent({ ...globalContent, heroTitleFirst: e.target.value })}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-black italic text-white uppercase" 
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Platform Name (Part 2)</label>
                        <input 
                          type="text" 
                          value={globalContent.heroTitleLast} 
                          onChange={(e) => setGlobalContent({ ...globalContent, heroTitleLast: e.target.value })}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-black italic text-white uppercase" 
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Hero Description (Subtext)</label>
                        <input 
                          type="text" 
                          value={globalContent.heroSubTitle} 
                          onChange={(e) => setGlobalContent({ ...globalContent, heroSubTitle: e.target.value })}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-zinc-400" 
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Hero Badge Slogan</label>
                        <input 
                          type="text" 
                          value={globalContent.heroBadge} 
                          onChange={(e) => setGlobalContent({ ...globalContent, heroBadge: e.target.value })}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-zinc-400" 
                        />
                      </div>

                      <h4 className="text-[10px] font-black text-purple-500 uppercase tracking-widest border-b border-zinc-800 pb-2 mt-8">Hero Call to Action</h4>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">CTA Button Text</label>
                          <input 
                            type="text" 
                            value={globalContent.heroCtaText} 
                            onChange={(e) => setGlobalContent({ ...globalContent, heroCtaText: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white" 
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Primary CTA Link / ID</label>
                          <input 
                            type="text" 
                            value={globalContent.heroCtaLink} 
                            onChange={(e) => setGlobalContent({ ...globalContent, heroCtaLink: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-zinc-500 font-mono" 
                          />
                        </div>
                        <div className="pt-4 mt-4 border-t border-zinc-800/50">
                          <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Secondary CTA Button Text</label>
                          <input 
                            type="text" 
                            value={globalContent.heroSecondaryCtaText} 
                            onChange={(e) => setGlobalContent({ ...globalContent, heroSecondaryCtaText: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white" 
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Secondary CTA Link / ID</label>
                          <input 
                            type="text" 
                            value={globalContent.heroSecondaryCtaLink} 
                            onChange={(e) => setGlobalContent({ ...globalContent, heroSecondaryCtaLink: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-zinc-500 font-mono" 
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-[10px] font-black text-purple-500 uppercase tracking-widest border-b border-zinc-800 pb-2">Team Section</h4>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Section Headline</label>
                        <input 
                          type="text" 
                          value={globalContent.teamSectionTitle} 
                          onChange={(e) => setGlobalContent({ ...globalContent, teamSectionTitle: e.target.value })}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-black italic text-white uppercase" 
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Section Subtext</label>
                        <textarea 
                          value={globalContent.teamSectionDesc} 
                          onChange={(e) => setGlobalContent({ ...globalContent, teamSectionDesc: e.target.value })}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-zinc-400 h-24 resize-none" 
                        />
                      </div>
                    </div>

                    <h4 className="text-[10px] font-black text-purple-500 uppercase tracking-widest border-b border-zinc-800 pb-2 mt-8">Sponsorship Buttons</h4>
                    <div className="space-y-4">
                      {(globalContent.inquiryButtons || []).map((btn: any, idx: number) => (
                        <div key={`inq-btn-${idx}`} className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800 space-y-3">
                          <div className="flex gap-4">
                            <div className="flex-1">
                              <input 
                                type="text" 
                                placeholder="Label"
                                value={btn.label} 
                                onChange={(e) => {
                                  const nb = [...globalContent.inquiryButtons];
                                  nb[idx].label = e.target.value;
                                  setGlobalContent({ ...globalContent, inquiryButtons: nb });
                                }}
                                className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white uppercase font-black" 
                              />
                            </div>
                            <div className="w-32">
                              <select 
                                value={btn.type} 
                                onChange={(e) => {
                                  const nb = [...globalContent.inquiryButtons];
                                  nb[idx].type = e.target.value;
                                  setGlobalContent({ ...globalContent, inquiryButtons: nb });
                                }}
                                className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white"
                              >
                                <option value="Mail">Mail</option>
                                <option value="Zap">Zap (Partner)</option>
                                <option value="MessageSquare">WhatsApp</option>
                                <option value="Phone">Phone</option>
                              </select>
                            </div>
                          </div>
                          <input 
                            type="text" 
                            placeholder="Link (e.g. mailto: or https://wa.me/)"
                            value={btn.link} 
                            onChange={(e) => {
                              const nb = [...globalContent.inquiryButtons];
                              nb[idx].link = e.target.value;
                              setGlobalContent({ ...globalContent, inquiryButtons: nb });
                            }}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-zinc-400 font-mono" 
                          />
                          <div className="flex items-center gap-2">
                            <label className="flex items-center gap-2 text-[10px] text-zinc-500 uppercase font-black cursor-pointer">
                              <input 
                                type="checkbox" 
                                checked={btn.primary} 
                                onChange={(e) => {
                                  const nb = [...globalContent.inquiryButtons];
                                  nb[idx].primary = e.target.checked;
                                  setGlobalContent({ ...globalContent, inquiryButtons: nb });
                                }}
                              />
                              Primary Highlight Style?
                            </label>
                            <button 
                              onClick={() => {
                                const nb = globalContent.inquiryButtons.filter((_:any, i:number) => i !== idx);
                                setGlobalContent({ ...globalContent, inquiryButtons: nb });
                              }}
                              className="ml-auto text-red-500 hover:text-red-400 p-1"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      ))}
                      <button 
                        onClick={() => {
                          const nb = [...(globalContent.inquiryButtons || []), { label: 'New Action', link: '#', type: 'MessageSquare', primary: false }];
                          setGlobalContent({ ...globalContent, inquiryButtons: nb });
                        }}
                        className="w-full py-3 border-2 border-dashed border-zinc-800 rounded-xl text-zinc-500 font-black uppercase text-[10px] tracking-widest hover:border-purple-500 hover:text-purple-500 transition-all flex items-center justify-center gap-2"
                      >
                        <Plus size={16} /> Add Inquiry Action
                      </button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-[10px] font-black text-purple-500 uppercase tracking-widest border-b border-zinc-800 pb-2">Footer & Contact</h4>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Contact Headline</label>
                        <input 
                          type="text" 
                          value={globalContent.inquiryTitle} 
                          onChange={(e) => setGlobalContent({ ...globalContent, inquiryTitle: e.target.value })}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-black italic text-white uppercase" 
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Contact Description</label>
                        <textarea 
                          value={globalContent.inquiryDesc} 
                          onChange={(e) => setGlobalContent({ ...globalContent, inquiryDesc: e.target.value })}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-zinc-400 h-24 resize-none" 
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black uppercase text-zinc-500 mb-2">Copyright Disclaimer</label>
                        <input 
                          type="text" 
                          value={globalContent.footerCopyright} 
                          onChange={(e) => setGlobalContent({ ...globalContent, footerCopyright: e.target.value })}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-zinc-500" 
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          {activeTab === 10 && (
            /* Navigation Settings */
            <div className="space-y-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black italic text-white uppercase tracking-tighter">Site Navigation Menu</h3>
                <button 
                  onClick={() => {
                    const newNav = [...nav, { name: 'New Link', link: '#' }];
                    setNav(newNav);
                    handleSave('/api/nav', newNav);
                  }}
                  className="px-6 py-3 bg-purple-600 text-white rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-purple-500 transition-all flex items-center gap-2"
                >
                  <Plus size={16} /> Add Link
                </button>
              </div>
              <div className="space-y-4">
                {nav.map((n, i) => (
                  <div key={`nav-edit-${i}`} className="bg-[#0a0a1a] p-6 rounded-2xl border border-zinc-800 flex items-center gap-6">
                    <div className="flex-1">
                      <label className="block text-[10px] font-black text-zinc-500 uppercase mb-2">Label Name</label>
                      <input 
                        type="text" 
                        value={n.name} 
                        onChange={(e) => {
                          const nn = [...nav];
                          nn[i].name = e.target.value;
                          setNav(nn);
                        }}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-bold text-white" 
                      />
                    </div>
                    <div className="flex-1">
                      <label className="block text-[10px] font-black text-zinc-500 uppercase mb-2">Destination Anchor / URL</label>
                      <input 
                        type="text" 
                        value={n.link} 
                        onChange={(e) => {
                          const nn = [...nav];
                          nn[i].link = e.target.value;
                          setNav(nn);
                        }}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs font-mono text-zinc-500" 
                      />
                    </div>
                    <div className="flex gap-2 self-end">
                       <button onClick={() => handleSave('/api/nav', nav)} className="p-4 bg-zinc-800 text-zinc-400 rounded-xl hover:text-white transition-all"><Save size={16}/></button>
                       <button onClick={() => {
                         const nn = nav.filter((_, idx) => idx !== i);
                         setNav(nn);
                         handleSave('/api/nav', nn);
                       }} className="p-4 bg-red-600/10 text-red-500 border border-red-600/20 rounded-xl hover:bg-red-600 hover:text-white transition-all"><Trash2 size={16}/></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>


      {/* Floating Loading / Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className={`fixed bottom-10 right-10 z-[100] px-8 py-5 rounded-3xl border shadow-2xl flex items-center gap-4 ${
              toast.type === 'success' ? 'bg-zinc-900 border-green-500/50 text-white' : 'bg-red-900 border-red-500/50 text-white'
            }`}
          >
            {toast.type === 'success' ? <CheckCircle2 className="text-green-500"/> : <AlertCircle className="text-red-500"/>}
            <div className="flex flex-col">
              <span className="text-xs font-black uppercase tracking-widest">{toast.type === 'success' ? 'System Success' : 'Input Error'}</span>
              <span className="text-[10px] font-bold text-zinc-400 mt-1">{toast.message}</span>
            </div>
          </motion.div>
        )}

        {loading && (
          <div className="fixed inset-0 z-[110] bg-black/40 backdrop-blur-[2px] flex items-center justify-center pointer-events-none">
             <div className="bg-black/80 p-8 rounded-3xl border border-white/10 flex flex-col items-center gap-4">
                <RefreshCcw size={24} className="animate-spin text-purple-500" />
                <span className="text-xs font-black uppercase tracking-[0.3em] text-white">Publishing Data...</span>
             </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
