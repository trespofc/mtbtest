import https from 'https';

https.get('https://metal-blade-int-professional-free-fire-esports-44266003352.asia-southeast1.run.app/assets/index-lVdIEn8O.js', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    console.log(data.substring(0, 1000));
    const classes = new Set();
    const classRe = /className:\s*["']([^"']+)["']/g;
    let match;
    while ((match = classRe.exec(data)) !== null) {
      match[1].split(' ').forEach(c => classes.add(c));
    }
    console.log("=== ALL CLASSES ===");
    console.log(Array.from(classes).join(' '));
    
    console.log("=== RAW STRINGS OVER 15 CHARS ===");
    const textRe = /["']([^"']{15,100})["']/g;
    const texts = [];
    while ((match = textRe.exec(data)) !== null) {
      if(!match[1].includes('/') && !match[1].includes('{') && match[1].includes(' ')) texts.push(match[1]);
    }
    console.log(texts.join('\n').substring(0, 2000));
  });
}).on('error', (err) => {
  console.log('Error: ', err.message);
});
