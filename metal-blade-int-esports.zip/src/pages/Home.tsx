import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Users, 
  Gamepad2, 
  ChevronRight, 
  Youtube, 
  Instagram, 
  Facebook, 
  MessageSquare,
  Play,
  Mail,
  Zap,
  Phone,
  Calendar,
  X,
  Radio,
  ArrowRight,
  Network,
  Flame,
  Menu,
  Lock
} from 'lucide-react';
import { Link } from 'react-router-dom';

// Fallback Constants (In case server is empty)
export default function Home() {
  const [selectedTournament, setSelectedTournament] = useState<any>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [lang, setLang] = useState('EN');
  const [sections, setSections] = useState<any[]>([]);
  const [tournaments, setTournaments] = useState<any[]>([]);
  const [theme, setTheme] = useState<any>({ type: 'dark', primary: '#b026ff', secondary: '#c026d3' });
  const [seo, setSeo] = useState<any>({});
  const [ads, setAds] = useState<any>({});
  const [team, setTeam] = useState<any[]>([]);
  const [stats, setStats] = useState<any[]>([]);
  const [socials, setSocials] = useState<any[]>([]);
  const [sponsors, setSponsors] = useState<string[]>([]);
  const [nav, setNav] = useState<any[]>([]);
  const [globalContent, setGlobalContent] = useState<any>({
    heroTitleFirst: 'METAL',
    heroTitleLast: 'BLADE',
    heroSubTitle: 'Professional Free Fire team',
    heroBadge: 'Forged in fire, built to conquer',
    footerCopyright: '© 2026 Metal Blade Int. All Rights Reserved.',
    inquiryTitle: 'Sponsorship & Inquiry.',
    inquiryDesc: "Bring your brand to the center of Bangladesh's Free Fire competitive scene. Partner with the elite.",
    teamSectionTitle: 'MANAGEMENT TEAM',
    teamSectionDesc: 'The visionary leaders and dedicated specialists driving our competitive excellence and organizational growth.',
  });

  const languages = ['EN', 'BN', 'ES', 'HI'];

  useEffect(() => {
    fetch('/api/sections').then(r => r.json()).then(setSections);
    fetch('/api/tournaments').then(r => r.json()).then(setTournaments);
    fetch('/api/theme').then(r => r.json()).then(setTheme);
    fetch('/api/seo').then(r => r.json()).then(setSeo);
    fetch('/api/ads').then(r => r.json()).then(setAds);
    fetch('/api/team').then(r => r.json()).then(setTeam);
    fetch('/api/stats').then(r => r.json()).then(setStats);
    fetch('/api/socials').then(r => r.json()).then(setSocials);
    fetch('/api/sponsors').then(r => r.json()).then(setSponsors);
    fetch('/api/content').then(r => r.json()).then(setGlobalContent);
    fetch('/api/nav').then(r => r.json()).then(setNav);
  }, []);

  useEffect(() => {
    if (selectedTournament) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [selectedTournament]);

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    
    if (id === 'top') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
  
      window.scrollTo({
           top: offsetPosition,
           behavior: "smooth"
      });
    }
  };

  const getFilteredTournaments = (filter: string) => {
    return tournaments.filter(t => t.status === filter);
  };

  return (
    <div className={`min-h-screen ${theme.type === 'white' ? 'bg-zinc-50 text-zinc-900' : 'bg-black text-white'} font-sans selection:bg-purple-500 selection:text-black mt-0 relative`}>
      
      {/* Dynamic SEO Injection */}
      {seo.title && <title>{seo.title}</title>}
      {seo.verificationHeader && <div dangerouslySetInnerHTML={{ __html: seo.verificationHeader }} />}

      {/* Live Animated Background */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <motion.div 
          animate={{ x: [0, 100, 0], y: [0, -50, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] blur-[120px] rounded-full mix-blend-screen"
          style={{ backgroundColor: `${theme.primary}20` }}
        />
        <motion.div 
          animate={{ x: [0, -100, 0], y: [0, 100, 0] }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] blur-[150px] rounded-full mix-blend-screen"
          style={{ backgroundColor: `${theme.secondary}20` }}
        />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150"></div>
      </div>

      {/* Ad Header */}
      {ads.header && (
        <div className="w-full bg-zinc-900/50 border-b border-zinc-800 flex justify-center py-4 relative z-50">
          <div dangerouslySetInnerHTML={{ __html: ads.header }} />
        </div>
      )}

      {/* Sticky Top Header */}
      <div className="sticky top-0 w-full z-50">
        {/* Top Marquee */}
        <div className="w-full overflow-hidden flex items-center py-2 sm:py-2.5" style={{ backgroundColor: theme.primary }}>
          <div className="flex whitespace-nowrap animate-marquee items-center text-black">
            {[...Array(20)].map((_, i) => (
              <div key={`banner-marquee-${i}`} className="flex items-center">
                <span className="font-black italic uppercase tracking-widest text-sm sm:text-base px-6">
                  {seo.title || "METAL BLADE INT. ESPORTS"}
                </span>
                <span className="text-black/80 text-xl leading-none">&bull;</span>
              </div>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <motion.nav 
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className={`${theme.type === 'white' ? 'bg-white/80' : 'bg-black/80'} backdrop-blur-md border-b border-white/5 py-4`}
        >
          <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center justify-between">
            <div className="flex-shrink-0 flex items-center gap-2 group cursor-pointer font-black italic uppercase tracking-tighter">
              <div className={`relative flex items-center justify-center w-10 h-10 md:w-12 md:h-12 ${theme.type === 'white' ? 'bg-zinc-100' : 'bg-[#120224]'} rounded-full border border-purple-500 overflow-hidden group-hover:shadow-[0_0_15px_rgba(176,38,255,0.6)] transition-all`}>
                {theme.logo ? (
                  <img src={theme.logo} alt="Logo" className="w-8 h-8 object-contain" />
                ) : (
                  <svg viewBox="0 0 24 24" fill={theme.primary} className="w-6 h-6 md:w-7 md:h-7 absolute animate-[spin_10s_linear_infinite]">
                    <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
                  </svg>
                )}
              </div>
              <div className="flex flex-col leading-[0.8] mt-1 relative">
                <span className={`${theme.type === 'white' ? 'text-zinc-900' : 'text-white'} text-lg md:text-2xl tracking-widest drop-shadow-[0_0_5px_rgba(255,255,255,0.3)]`}>METAL</span>
                <span className="text-xl md:text-3xl drop-shadow-[0_0_10px_rgba(176,38,255,0.6)] ml-1" style={{ color: theme.primary }}>BLADE</span>
              </div>
            </div>
            
            <div className="md:hidden flex items-center">
              <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-lg text-white hover:bg-zinc-800 transition-colors"
              >
                {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>

            <div className="hidden lg:flex items-center space-x-6 xl:space-x-10 text-[11px] xl:text-xs tracking-[0.2em] font-black italic uppercase text-zinc-400">
              {nav.map((item, idx) => (
                <a 
                  key={`nav-${idx}`}
                  href={item.link} 
                  onClick={(e) => {
                    if (item.link.startsWith('#')) scrollToSection(e, item.link.substring(1) || 'top');
                  }} 
                  className={`${theme.type === 'white' && idx === 0 ? 'text-zinc-900' : theme.type !== 'white' && idx === 0 ? 'text-white' : ''} hover:text-purple-500 transition-colors relative px-2 py-1 group`}
                >
                  {item.name}
                  {idx === 0 && <span className="absolute -bottom-2 left-0 w-full h-[2px]" style={{ backgroundColor: theme.primary }}></span>}
                  {idx !== 0 && <span className="absolute -bottom-2 left-0 w-0 h-[2px] transition-all group-hover:w-full" style={{ backgroundColor: theme.primary }}></span>}
                </a>
              ))}

              {/* Language Selector */}
              <div className="relative group/lang border-l border-zinc-800 ml-4 pl-4 flex items-center">
                <select 
                  value={lang} 
                  onChange={(e) => setLang(e.target.value)}
                  className="bg-transparent border-none text-zinc-500 font-black tracking-widest text-[10px] uppercase cursor-pointer hover:text-white transition-colors focus:outline-none appearance-none pr-4"
                >
                  {languages.map(l => <option key={`lang-${l}`} value={l} className="bg-black text-white">{l}</option>)}
                </select>
                <div className="absolute right-0 pointer-events-none opacity-50 group-hover/lang:opacity-100 transition-opacity">
                  <ChevronRight size={12} className="rotate-90" />
                </div>
              </div>
            </div>
          </div>
        </motion.nav>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="lg:hidden absolute top-full left-0 w-full bg-black/95 backdrop-blur-xl border-b border-purple-900/30 overflow-hidden shadow-2xl"
            >
              <div className="flex flex-col px-6 py-4 space-y-4 font-black italic uppercase tracking-widest text-sm">
                {nav.map((item, idx) => (
                  <a 
                    key={`mobile-nav-${idx}`}
                    href={item.link} 
                    onClick={(e) => {
                      if (item.link.startsWith('#')) scrollToSection(e, item.link.substring(1) || 'top');
                    }} 
                    className={`py-2 ${idx === 0 ? 'text-[#b026ff]' : 'text-zinc-400 hover:text-white'}`}
                  >
                    {item.name}
                  </a>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Dynamic Sections Loop */}
      {sections.filter(s => s.visible).sort((a,b) => a.order - b.order).map((section) => {
        if (section.id === 'hero') {
          return (
            <header key={section.id} className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-black border-b border-purple-900/20">
              <div className="absolute inset-0 bg-[radial-gradient(#3a1e50_1px,transparent_1px)] [background-size:24px_24px] opacity-20 z-[0]"></div>
              
              {/* Animated Glow */}
              <motion.div 
                animate={{ scale: [1, 1.2, 1], opacity: [0.15, 0.35, 0.15], rotate: [0, 180, 360] }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] blur-[100px] rounded-full z-[0]"
                style={{ backgroundColor: `${theme.primary}20` }}
              ></motion.div>

              <div className="relative z-10 text-center px-4 max-w-3xl flex flex-col items-center gap-8 mt-10">
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 1.2, type: "spring", bounce: 0.2 }}
                  className="flex flex-col items-center relative"
                >
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[35vw] md:w-[22vw] h-[35vw] md:h-[22vw] opacity-30 z-[0] pointer-events-none"
                  >
                    <svg viewBox="0 0 24 24" fill={theme.primary}>
                      <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
                    </svg>
                  </motion.div>
                  
                  <h1 className="text-[18vw] md:text-[11vw] font-black italic uppercase leading-[0.8] tracking-widest text-[#f5f5f5] drop-shadow-[0_0_15px_rgba(255,255,255,0.4)] z-10">
                    {globalContent.heroTitleFirst}
                  </h1>
                  <div className="flex items-center justify-center relative z-10 mt-1">
                    <h1 className="text-[21vw] md:text-[13vw] font-black italic uppercase leading-[0.7] drop-shadow-[0_0_35px_rgba(176,38,255,0.6)] ml-2 md:ml-4 flex items-end" style={{ color: theme.primary }}>
                      {globalContent.heroTitleLast}
                      <span className="text-[2.5vw] md:text-[1.5vw] tracking-[0.4em] font-bold mb-4 md:mb-6 ml-2 drop-shadow-[0_0_10px_rgba(176,38,255,0.8)]" style={{ color: theme.primary }}>
                        ESPORTS
                      </span>
                    </h1>
                  </div>
                </motion.div>

                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4, duration: 1, ease: "easeOut" }}
                  className="mt-6 w-full max-w-lg border rounded-full py-3 px-6 flex items-center justify-center gap-3 bg-[#b026ff]/10 backdrop-blur-sm shadow-[0_0_20px_rgba(176,38,255,0.2)]"
                  style={{ borderColor: `${theme.primary}60` }}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 shrink-0 animate-pulse" style={{ color: theme.primary }}>
                    <path fillRule="evenodd" d="M14.615 1.595a.75.75 0 01.359.852L12.982 9.75h7.268a.75.75 0 01.548 1.262l-10.5 11.25a.75.75 0 01-1.272-.71l1.992-7.302H3.75a.75.75 0 01-.548-1.262l10.5-11.25a.75.75 0 01.913-.143z" clipRule="evenodd" />
                  </svg>
                  <span className="text-xs sm:text-sm font-bold tracking-[0.25em] uppercase text-center leading-relaxed" style={{ color: theme.primary }}>
                    {globalContent.heroBadge}
                  </span>
                </motion.div>

                <motion.p 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5, duration: 1 }}
                  className="text-zinc-300 max-w-xl text-base sm:text-lg md:text-xl font-medium mt-2 leading-relaxed px-4"
                >
                   {globalContent.heroSubTitle || seo.description || "Premier Free Fire Esports organization from Bangladesh. Supporting local talent and dominating the battlefield."}
                </motion.p>
                
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 }}
                  className="flex flex-col w-full sm:w-auto items-center justify-center gap-4 sm:gap-6 mt-6"
                >
                  <motion.a 
                    animate={{ scale: [1, 1.05, 1], boxShadow: ["0 0 15px rgba(176,38,255,0.4)", "0 0 30px rgba(176,38,255,0.8)", "0 0 15px rgba(176,38,255,0.4)"] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                    href={globalContent.heroCtaLink || "#tournaments"} 
                    onClick={(e) => {
                      if (globalContent.heroCtaLink?.startsWith('#')) scrollToSection(e, globalContent.heroCtaLink.substring(1));
                    }}
                    className="w-full sm:w-auto px-10 py-5 text-white font-black italic uppercase tracking-widest flex items-center justify-center gap-3 text-sm md:text-base rounded-xl cursor-pointer"
                    style={{ backgroundColor: theme.primary }}
                  >
                    {globalContent.heroCtaText || "Live Tournaments"}
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>
                  </motion.a>
                  <motion.a 
                    animate={{ borderColor: ["rgba(39,39,42,1)", "rgba(176,38,255,0.5)", "rgba(39,39,42,1)"] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                    href={globalContent.heroSecondaryCtaLink || "#contact"} 
                    onClick={(e) => {
                      if (globalContent.heroSecondaryCtaLink?.startsWith('#')) scrollToSection(e, globalContent.heroSecondaryCtaLink.substring(1));
                    }}
                    className="w-full sm:w-auto px-10 py-5 bg-transparent border-2 border-zinc-800 text-zinc-300 font-black italic uppercase tracking-widest flex items-center justify-center text-sm md:text-base rounded-xl cursor-pointer"
                  >
                    {globalContent.heroSecondaryCtaText || "Become a Partner"}
                  </motion.a>
                </motion.div>
              </div>
            </header>
          );
        }

        if (section.id === 'stats') {
          return (
            <section key={section.id} className={`py-20 ${theme.type === 'white' ? 'bg-zinc-100' : 'bg-[#05000a]'} relative z-20 border-b border-purple-900/30`}>
              <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
                {stats.map((s, i) => {
                  const IconComponent = s.icon === 'Trophy' ? Trophy : s.icon === 'Users' ? Users : s.icon === 'Network' ? Network : Flame;
                  return (
                    <motion.div 
                      key={`stat-card-${i}`}
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: false, margin: "-50px" }}
                      whileHover={{ scale: 1.05, y: -5 }}
                      transition={{ delay: i * 0.1, type: "spring" }}
                      className={`rounded-[2rem] border p-8 flex flex-col items-center justify-center min-h-[220px] shadow-sm hover:shadow-xl transition-all cursor-pointer ${theme.type === 'white' ? 'bg-white border-zinc-200' : 'bg-[#0c0518] border-purple-500/20'}`}
                    >
                      <div className="mb-4">
                        <IconComponent size={42} className="text-[#b026ff] drop-shadow-[0_0_10px_rgba(176,38,255,0.8)]" />
                      </div>
                      <h4 className="text-3xl md:text-4xl font-black italic tracking-widest drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]" style={{ fontFamily: "'Space Grotesk', sans-serif", color: theme.type === 'white' ? 'black' : 'white' }}>{s.val}</h4>
                      <p className="text-zinc-400 text-[10px] sm:text-xs font-bold uppercase tracking-[0.2em] mt-3">{s.label}</p>
                    </motion.div>
                  )
                })}
              </div>
            </section>
          );
        }

        if (section.type === 'tournament') {
          const list = getFilteredTournaments(section.filter || 'LIVE');
          if (list.length === 0) return null;

          return (
            <section key={section.id} id="tournaments" className={`py-32 ${theme.type === 'white' ? 'bg-white' : 'bg-zinc-950'} relative overflow-hidden`}>
              <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-purple-500/50 to-transparent"></div>
              <div className="max-w-7xl mx-auto px-4">
                <div className="mb-16">
                  <h2 className="font-bold uppercase tracking-[0.3em] text-xs mb-2" style={{ color: theme.primary }}>{section.filter}</h2>
                  <h3 className={`text-5xl font-black italic uppercase tracking-tighter ${theme.type === 'white' ? 'text-black' : 'text-white'}`}>{section.title}</h3>
                </div>
                <div className="flex overflow-x-auto snap-x snap-mandatory hide-scrollbar gap-6 pb-8 -mx-4 px-4 md:mx-0 md:px-0">
                  {list.map((t, i) => (
                    <motion.div 
                      key={`tournament-card-${section.id}-${t.id || i}`}
                      initial={{ opacity: 0.4, scale: 0.85 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: false, amount: 0.6 }}
                      whileHover={{ scale: 1.02, y: -5 }}
                      className={`shrink-0 snap-center w-[85vw] md:w-[700px] lg:w-[850px] group relative flex flex-col md:flex-row rounded-[2rem] overflow-hidden border transition-all shadow-lg ${theme.type === 'white' ? 'bg-white border-zinc-200' : 'bg-[#0c0518] border-purple-900/30'}`}
                    >
                      <div 
                        className="w-full md:w-80 h-56 md:h-auto md:min-h-[250px] relative bg-zinc-900 overflow-hidden shrink-0 cursor-pointer"
                        onClick={(e) => { e.stopPropagation(); setSelectedTournament({ ...t, modalView: 'post' }); }}
                      >
                        <img src={t.showChampion ? t.championBanner : t.img} alt={t.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-70 group-hover:opacity-100" />
                        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent md:bg-gradient-to-t md:from-black/80 md:to-transparent opacity-60"></div>
                        <div className={`absolute top-6 left-6 flex items-center gap-2 text-white text-[10px] font-black uppercase px-3 py-1.5 rounded-full shadow-lg border border-white/20`} style={{ backgroundColor: t.status === 'LIVE' ? '#ef4444' : t.status === 'UPCOMING' ? theme.primary : '#3f3f46' }}>
                          {t.status === 'LIVE' && <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>} {t.status}
                        </div>
                      </div>
                      <div className="p-8 md:p-10 flex flex-col justify-between flex-1 relative">
                        <div className="absolute top-0 right-0 p-8 hidden md:block opacity-5 group-hover:opacity-20 transition-opacity">
                          <Trophy size={100} />
                        </div>
                        <div className="relative z-10 mb-8 md:mb-0">
                          <h4 className={`text-3xl lg:text-4xl font-black italic uppercase mb-3 leading-none tracking-tight group-hover:text-purple-400 transition-colors drop-shadow-sm`}>{t.title}</h4>
                          <div className="flex flex-wrap gap-2 mb-6">
                            <span className="px-2 py-1 bg-purple-900/10 text-purple-400 rounded-md border border-purple-500/20 text-xs font-bold">{t.prize} Prize</span>
                            <span className="px-2 py-1 bg-zinc-800/10 text-zinc-400 rounded-md text-xs font-bold">{t.teams}</span>
                            <span className="px-2 py-1 bg-zinc-800/10 text-zinc-400 rounded-md text-xs font-bold">{t.fee}</span>
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center justify-end gap-4 relative z-10 mt-auto">
                          <span 
                            className="text-xs font-black uppercase tracking-widest group-hover:translate-x-1 transition-transform cursor-pointer hover:text-purple-400 relative z-20 py-2"
                            style={{ color: theme.primary }}
                            onClick={(e) => { e.stopPropagation(); setSelectedTournament({ ...t, modalView: 'post' }); }}
                          >
                            View More →
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </section>
          );
        }

        if (section.type === 'normal') {
          return (
            <section key={section.id} className={`py-32 ${theme.type === 'white' ? 'bg-zinc-50' : 'bg-transparent'} relative border-t border-purple-900/30 overflow-hidden z-10`}>
              <div className="max-w-7xl mx-auto px-4 relative">
                 <h2 className="font-bold uppercase tracking-[0.3em] text-xs mb-3 flex items-center gap-2" style={{ color: theme.primary }}><Flame size={14} className="animate-pulse" /> METAL BLADE</h2>
                 <h3 className={`text-4xl md:text-5xl lg:text-6xl font-black italic uppercase tracking-tighter mb-6 leading-[0.9] ${theme.type === 'white' ? 'text-black' : 'text-white'}`}>{section.title}</h3>
                 <div className={`text-sm md:text-base leading-relaxed font-medium ${theme.type === 'white' ? 'text-zinc-600' : 'text-zinc-400'}`} dangerouslySetInnerHTML={{ __html: section.content }} />
              </div>
            </section>
          );
        }

        return null;
      })}

      {/* Team / Organization */}
      <section id="team" className="py-24 bg-[#05000a] relative border-t border-purple-900/30 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 relative z-10 w-full mb-16">
          <div className="text-center">
            <h2 className="text-4xl md:text-5xl font-black uppercase text-fuchsia-500 mb-4 tracking-wide">{globalContent.teamSectionTitle}</h2>
            <p className="text-zinc-400 text-sm md:text-base max-w-2xl mx-auto tracking-wide">{globalContent.teamSectionDesc}</p>
          </div>
        </div>
        <div className="flex overflow-hidden group w-full">
          <motion.div 
            animate={{ x: ["0%", "-50%"] }} 
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
            className="flex gap-6 pl-6 w-max"
          >
            {[...team, ...team].map((m, i) => (
              <div key={`team-marquee-${i}`} className="w-[280px] md:w-[320px] flex-shrink-0 bg-[#0c0518] border border-purple-500/20 rounded-2xl p-8 flex flex-col items-center text-center group/card hover:border-purple-500/50 hover:shadow-[0_0_30px_rgba(168,85,247,0.15)] transition-all duration-300 relative">
                <div className="absolute inset-0 bg-gradient-to-b from-purple-500/5 to-transparent rounded-2xl opacity-0 group-hover/card:opacity-100 transition-opacity duration-500"></div>
                <div className="w-28 h-28 bg-black rounded-full mb-6 border-2 border-purple-900/50 group-hover/card:border-purple-500 overflow-hidden transition-colors duration-300 relative z-10 flex items-center justify-center">
                  <img src={m.img || `https://api.dicebear.com/7.x/initials/svg?seed=${m.name}&backgroundColor=000000&textColor=d946ef`} alt={m.name} className="w-full h-full object-cover" />
                </div>
                <p className="text-fuchsia-500 font-black uppercase tracking-wider text-[11px] mb-3 leading-snug relative z-10">{m.role}</p>
                <h3 className="text-white font-black uppercase text-xl mb-4 relative z-10 tracking-tight">{m.name}</h3>
                <p className="text-zinc-400 text-xs leading-relaxed relative z-10">{m.desc}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Sponsors Marquee */}
      <div id="partners" className="bg-zinc-950 py-16 border-y border-zinc-900 overflow-hidden flex scroll-mt-24">
        <motion.div 
          animate={{ x: ["0%", "-50%"] }} 
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }} 
          className="flex gap-24 items-center w-max pr-24"
        >
          {sponsors.map((s, i) => (
            <span key={`sponsor-${i}`} className="text-3xl md:text-6xl font-black italic uppercase tracking-tighter text-zinc-900 hover:text-zinc-800 select-none whitespace-nowrap">{s}</span>
          ))}
          {sponsors.map((s, i) => (
            <span key={`sponsor-dup-${i}`} className="text-3xl md:text-6xl font-black italic uppercase tracking-tighter text-zinc-900 hover:text-zinc-800 select-none whitespace-nowrap">{s}</span>
          ))}
        </motion.div>
      </div>

      {/* Socials / Stay Connected */}
      <section id="contact" className="py-32 bg-[#05000a] relative border-t border-purple-900/30 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.02]"></div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: false, margin: "-100px" }} variants={{ hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.1 } } }}>
              <motion.h2 variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }} className="text-4xl md:text-5xl lg:text-7xl font-black uppercase tracking-tighter leading-none text-white mb-4">
                STAY CONNECTED<span style={{ color: theme.primary }}>.</span>
              </motion.h2>
              <div id="social" className="grid grid-cols-2 gap-4 scroll-mt-24 mt-12" variants={{ hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.2 } } }}>
                 {socials.map((s, i) => {
                   const IconComponent = s.type === 'Facebook' ? Facebook : s.type === 'Youtube' ? Youtube : s.type === 'Instagram' ? Instagram : s.type === 'MessageSquare' ? MessageSquare : s.type === 'Play' ? Play : Youtube;
                   const colorClass = s.type === 'Facebook' ? 'text-zinc-400 group-hover:text-[#1877F2]' : s.type === 'Youtube' ? 'text-zinc-400 group-hover:text-[#FF0000]' : s.type === 'Instagram' ? 'text-zinc-400 group-hover:text-[#E1306C]' : s.type === 'MessageSquare' ? 'text-zinc-400 group-hover:text-[#5865F2]' : 'text-zinc-400 group-hover:text-white';
                   const borderClass = s.type === 'Facebook' ? 'border-purple-900/30 hover:border-[#1877F2]/50' : s.type === 'Youtube' ? 'border-purple-900/30 hover:border-[#FF0000]/50' : s.type === 'Instagram' ? 'border-purple-900/30 hover:border-[#E1306C]/50' : s.type === 'MessageSquare' ? 'border-purple-900/30 hover:border-[#5865F2]/50' : 'border-purple-900/30 hover:border-zinc-500/50';
                   const bgClass = s.type === 'Facebook' ? 'hover:bg-[#1877F2]/5' : s.type === 'Youtube' ? 'hover:bg-[#FF0000]/5' : s.type === 'Instagram' ? 'hover:bg-[#E1306C]/5' : s.type === 'MessageSquare' ? 'hover:bg-[#5865F2]/5' : 'hover:bg-white/5';
                   
                   return (
                     <motion.a key={`social-card-${i}`} variants={{ hidden: { opacity: 0, scale: 0.8 }, visible: { opacity: 1, scale: 1 } }} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} href={s.link} className={`p-6 md:p-8 bg-[#0c0518] rounded-2xl flex flex-col items-center justify-center text-center group transition-all duration-300 border shadow-sm relative overflow-hidden ${bgClass} ${borderClass}`}>
                       <div className={`transition-all duration-300 group-hover:-translate-y-1 relative z-10 ${colorClass}`}>
                         <IconComponent className="w-10 h-10 md:w-12 md:h-12 mb-3 md:mb-4" />
                       </div>
                       <span className="font-bold uppercase text-[10px] md:text-xs text-zinc-400 group-hover:text-white tracking-widest whitespace-pre-line leading-relaxed transition-colors duration-300 relative z-10">{s.platform}</span>
                     </motion.a>
                   );
                 })}
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: false }}
              whileHover={{ y: -5 }}
              className="p-8 md:p-12 rounded-[2.5rem] relative overflow-hidden group shadow-2xl flex flex-col border border-white/10"
              style={{ background: `linear-gradient(135deg, #1c053a, #4a0080, ${theme.primary})` }}
            >
              <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10"></div>
              <div className="relative z-10 flex flex-col h-full justify-between">
                <div>
                  <h2 className="text-3xl md:text-5xl font-black italic text-white uppercase mb-6 leading-tight drop-shadow-lg" dangerouslySetInnerHTML={{ __html: globalContent.inquiryTitle.replace('.','<br/>') }}></h2>
                  <p className="text-white/90 font-medium mb-10 max-w-sm text-sm md:text-base leading-relaxed drop-shadow-sm">{globalContent.inquiryDesc}</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 w-full flex-wrap">
                  {(globalContent.inquiryButtons || []).map((btn: any, idx: number) => {
                    const Icon = btn.type === 'Mail' ? Mail : btn.type === 'Zap' ? Zap : btn.type === 'Phone' ? Phone : MessageSquare;
                    return (
                      <motion.a 
                        key={`inq-btn-${idx}`}
                        whileHover={{ scale: 1.05 }} 
                        whileTap={{ scale: 0.95 }} 
                        href={btn.link} 
                        onClick={(e) => {
                          if (btn.link.startsWith('#')) scrollToSection(e, btn.link.substring(1));
                        }}
                        className={`inline-flex items-center justify-center gap-3 ${btn.primary ? 'bg-white text-black hover:bg-zinc-100 shadow-[0_0_20px_rgba(255,255,255,0.1)]' : 'bg-black text-white hover:bg-zinc-900 border border-white/5'} px-6 py-4 rounded-xl font-black italic uppercase tracking-widest transition-all text-[10px] md:text-xs relative flex-1 min-w-[140px] group/btn overflow-hidden`}
                      >
                        <div className={`absolute inset-x-0 bottom-0 h-1 ${btn.primary ? 'bg-black/20' : 'bg-white/20'} translate-y-full group-hover/btn:translate-y-0 transition-transform`}></div>
                        <span className="relative z-10">{btn.label}</span>
                        <Icon size={16} className="relative z-10" />
                      </motion.a>
                    );
                  })}
                  {(!globalContent.inquiryButtons || globalContent.inquiryButtons.length === 0) && (
                    <motion.a whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} href="mailto:metalbladeesporg@gmail.com" className="inline-flex items-center justify-center gap-3 bg-black text-white px-6 py-4 rounded-xl font-black italic uppercase tracking-widest hover:bg-zinc-900 transition-all text-[10px] md:text-xs relative flex-1 group/btn overflow-hidden">
                      <span className="relative z-10">Send Email</span>
                      <Mail size={16} className="relative z-10" />
                      <div className="absolute inset-0 bg-white/5 translate-y-full group-hover/btn:translate-y-0 transition-transform"></div>
                    </motion.a>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 bg-zinc-950 border-t border-zinc-900">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="text-center md:text-left flex flex-col items-center md:items-start">
             <div className="flex items-center gap-2 mb-4 group cursor-pointer w-full md:w-auto overflow-hidden">
               <div className="relative flex items-center justify-center w-10 h-10 bg-[#120224] rounded-full border border-purple-500 flex-shrink-0">
                 <svg viewBox="0 0 24 24" fill={theme.primary} className="w-5 h-5 group-hover:animate-spin">
                   <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
                 </svg>
               </div>
               <div className="flex flex-col leading-[0.8] text-left">
                 <span className="text-white text-lg tracking-widest drop-shadow-[0_0_5px_rgba(255,255,255,0.3)] font-black italic uppercase">{globalContent.heroTitleFirst}</span>
                 <span className="text-xl drop-shadow-[0_0_10px_rgba(176,38,255,0.6)] ml-1 font-black italic uppercase" style={{ color: theme.primary }}>{globalContent.heroTitleLast}</span>
               </div>
             </div>
             <p className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.4em]">{globalContent.footerCopyright}</p>
             <Link to="/admin" className="mt-4 flex items-center gap-2 text-zinc-800 hover:text-purple-500 transition-colors text-[10px] font-black uppercase tracking-[0.2em] group">
               <Lock size={10} className="opacity-50 group-hover:opacity-100" />
               Admin Command Center
             </Link>
          </div>
        </div>
      </footer>

      {/* Modal */}
      <AnimatePresence>
        {selectedTournament && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm"
          onClick={() => setSelectedTournament(null)}>
             <motion.div 
             onClick={(e) => e.stopPropagation()}
             initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} 
             className={`bg-[#05000a] border border-purple-900/30 rounded-2xl w-full max-w-lg overflow-hidden relative shadow-2xl flex flex-col max-h-[90vh]`}>
                
                <div className="absolute top-4 right-4 z-50 cursor-pointer p-2 bg-black/60 hover:bg-black/90 rounded-full text-white/70 hover:text-white transition-colors" onClick={() => setSelectedTournament(null)}>
                  <X size={24} />
                </div>

                <div className="w-full h-48 sm:h-64 relative bg-zinc-900 overflow-hidden shrink-0">
                  <img src={selectedTournament.img} alt={selectedTournament.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                  <div className="absolute bottom-4 left-6 right-6">
                    <p className="font-bold uppercase tracking-[0.2em] text-[10px] mb-1" style={{ color: theme.primary }}>{selectedTournament.status}</p>
                    <h3 className="text-2xl sm:text-3xl font-black italic uppercase tracking-tight text-white leading-none drop-shadow-lg">{selectedTournament.title}</h3>
                  </div>
                </div>
                <div className="p-6 sm:p-8 flex-col flex-1 overflow-y-auto hide-scrollbar bg-black">
                  <div className="space-y-4 mb-8">
                    <div className="flex items-center gap-4 bg-zinc-900/40 p-4 rounded-xl border border-zinc-800">
                      <div className="p-3 bg-purple-900/20 rounded-lg text-purple-400"><Trophy size={20} /></div>
                      <div>
                        <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Prize Pool</p>
                        <p className="text-base sm:text-lg font-black uppercase text-zinc-200">{selectedTournament.prize}</p>
                      </div>
                    </div>
                  </div>
                  <p className="text-zinc-400 text-sm leading-relaxed mb-8">{selectedTournament.description}</p>
                  <motion.button 
                    animate={{ scale: [1, 1.02, 1], boxShadow: ["0 0 5px rgba(176,38,255,0.2)", "0 0 15px rgba(176,38,255,0.5)", "0 0 5px rgba(176,38,255,0.2)"] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                    className="w-full py-4 rounded-xl text-white font-black italic uppercase tracking-widest transition-colors text-sm" 
                    style={{ backgroundColor: theme.primary }}
                    onClick={() => setSelectedTournament(null)}
                  >
                    Close Match Feed
                  </motion.button>
                </div>
             </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
