import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import AdminPanel from './components/AdminPanel';
import AdminLogin from './components/AdminLogin';

function App() {
  const [authToken, setAuthToken] = useState<string | null>(localStorage.getItem('admin_token'));

  const handleLogin = (token: string) => {
    localStorage.setItem('admin_token', token);
    setAuthToken(token);
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    setAuthToken(null);
  };

  return (
    <BrowserRouter>
      <Routes>
        {/* Public Landing Page */}
        <Route path="/" element={<Home />} />

        {/* Administration Gateway */}
        <Route 
          path="/admin" 
          element={
            authToken ? (
              <AdminPanel />
            ) : (
              <AdminLogin onLogin={handleLogin} />
            )
          } 
        />

        {/* Catch-all Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
